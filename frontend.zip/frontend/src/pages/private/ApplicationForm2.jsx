import SideBar from "../../components/sidebar/SideBar";

function ApplicationForm2() {
  return <SideBar>ApplicationForm2</SideBar>;
}

export default ApplicationForm2;
