function YesOrNoFieldWithFileUpload() {
  return <div>YesOrNoFieldWithFileUpload</div>;
}

export default YesOrNoFieldWithFileUpload;
